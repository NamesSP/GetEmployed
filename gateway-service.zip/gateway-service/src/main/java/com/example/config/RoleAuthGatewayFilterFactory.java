package com.example.config;

import com.example.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
public class RoleAuthGatewayFilterFactory
        extends AbstractGatewayFilterFactory<RoleAuthGatewayFilterFactory.Config> {

    private static final Logger logger = LoggerFactory.getLogger(RoleAuthGatewayFilterFactory.class);

    @Autowired
    private JwtUtil jwtUtil;

    public RoleAuthGatewayFilterFactory() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            ServerHttpRequest request = exchange.getRequest();
            String authHeader = request.getHeaders().getFirst("Authorization");

            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                logger.warn("Missing Authorization header for role check: {}", config.getRole());
                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                return exchange.getResponse().setComplete();
            }

            String token = authHeader.substring(7);

            // 1. Get the single role string (e.g., "ROLE_ADMIN") from JwtUtil
            String requiredRole = "ROLE_" + config.getRole().toUpperCase();
            String userRole = null;

            try {
                userRole = jwtUtil.getRoleFromToken(token);

                // If the user's role does not match the required role
                if (userRole == null || !userRole.equals(requiredRole)) {
                    logger.warn("Role mismatch: required {}, user has {}", requiredRole, userRole);
                    exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
                    return exchange.getResponse().setComplete();
                }

            } catch (Exception e) {
                // Catches token expiry, signature failure, etc., during claim
                // extraction/validation
                logger.error("JWT validation failed for request: {}", e.getMessage());
                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                return exchange.getResponse().setComplete();
            }

            logger.info("Role {} authorized for path: {}", requiredRole, request.getPath());
            return chain.filter(exchange);
        };
    }

    public static class Config {
        private String role; // e.g., "ADMIN", "SEEKER"

        // Shortcut field order ensures the 'role' property is easy to configure in
        // YML/Properties
        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }
    }

    @Override
    public List<String> shortcutFieldOrder() {
        return Arrays.asList("role");
    }
}
