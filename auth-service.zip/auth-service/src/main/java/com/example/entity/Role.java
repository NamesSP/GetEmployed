package com.example.entity;

public enum Role {
    ADMIN,
    SEEKER,
    RECRUITER
}
