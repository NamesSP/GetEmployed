package com.example.Validation;

import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class Test {
    @Autowired
    public static UserRepository repository;

}
